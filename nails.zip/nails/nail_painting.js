
Blockly.Blocks['paint_solid'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.setColour(290);
    this.appendDummyInput()
        .appendField("paint")
        .appendField(new Blockly.FieldColour("#ff0000"), "COLOR");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
  }
};

Blockly.JavaScript['paint_solid'] = function(block) {
  var colour_color = block.getFieldValue('COLOR');
  // TODO: Assemble JavaScript into code variable.
  var code = '...';
  return code;
};


Blockly.Blocks['paint_pattern'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.setColour(290);
    this.appendDummyInput()
        .appendField("paint")
        .appendField(new Blockly.FieldColour("#ff0000"), "COLOR")
        .appendField("with")
        .appendField(new Blockly.FieldColour("#ff0000"), "PAT_COLR")
        .appendField(new Blockly.FieldDropdown([["dots", "DOTS"], ["stripes", "STRIPES"], ["stars", "STARS"]]), "PATTERN");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
  }
};

Blockly.JavaScript['paint_pattern'] = function(block) {
  var colour_color = block.getFieldValue('COLOR');
  var colour_pat_colr = block.getFieldValue('PAT_COLR');
  var dropdown_pattern = block.getFieldValue('PATTERN');
  // TODO: Assemble JavaScript into code variable.
  var code = '...';
  return code;
};

Blockly.Blocks['nail_selection'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.setColour(0);
    this.appendStatementInput("NAME")
        .appendField(new Blockly.FieldTextInput("Nail"), "TEXT")
        .appendField(new Blockly.FieldDropdown([["1", "NAILONE"], ["2", "NAILTWO"], ["2", "NAILTHREE"]]), "NUMBER");
    this.setTooltip('');
  }
};

Blockly.JavaScript['nail_selection'] = function(block) {
  var statements_name = Blockly.JavaScript.statementToCode(block, 'NAME');
  var text_text = block.getFieldValue('TEXT');
  var dropdown_number = block.getFieldValue('NUMBER');
  // TODO: Assemble JavaScript into code variable.
  var code = '...';
  return code;
};

Blockly.Blocks['next_nail'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.setColour(15);
    this.appendDummyInput()
        .appendField("next nail");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
  }
};

Blockly.JavaScript['next_nail'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = '...';
  return code;
};

Blockly.Blocks['check_color'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.setColour(90);
    this.appendDummyInput()
        .appendField("nail is")
        .appendField(new Blockly.FieldColour("#ff0000"), "COLOR");
    this.setOutput(true);
    this.setTooltip('');
  }
};

Blockly.JavaScript['check_color'] = function(block) {
  var colour_color = block.getFieldValue('COLOR');
  // TODO: Assemble JavaScript into code variable.
  var code = '...';
  return code;
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.Blocks['check_painted'] = {
  init: function() {
    this.setHelpUrl('http://www.example.com/');
    this.setColour(90);
    this.appendDummyInput()
        .appendField("nail is")
        .appendField(new Blockly.FieldDropdown([["painted", "PAINTED"], ["empty", "EMPTY"]]), "PAINT");
    this.setOutput(true);
    this.setTooltip('');
  }
};

Blockly.JavaScript['check_painted'] = function(block) {
  var dropdown_paint = block.getFieldValue('PAINT');
  // TODO: Assemble JavaScript into code variable.
  var code = '...';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};

