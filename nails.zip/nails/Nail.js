
function Nail(nailNumber, x, y, height, width){
	this.nailNumber = nailNumber;
	this.x = x;
	this.y = y;
	//probably not necessary
	this.height = height;
	this.width = width;
	this.image_base = null;
	this.image_pattern = null;
	this.command_queue = [];
	//execute_id???
}

this.reset = function(){
	this.image_base = null;
	this.image_pattern = null;
	this.command_queue = [];
}

this.paintSolid = function(color, block_id){
	//use color to pick image
	var command = {command: 'paintSolid', color: color, block_id: block_id};
	this.command_queue.push(command);
}
this.exe_paintSolid = function(color){
	this.image_base = this.selectBase(color);
}

this.paintPatterned = function(pattern, color1, color2, block_id){
	//use colors and pattern to select image
	var command = {command: 'paintPatterned', pattern: pattern, color1: color1, color2: color2, block_id: block_id};
	this.command_queue.push(command);
}
this.exe_paintPatterned = function(pattern, color1, color2){
	this.image_base = this.selectBase(color1);
	this.image_pattern = this.selectPattern(pattern, color2)
}

this.removePaint = function(block_id){
	var command = {command: 'removePaint', block_id: block_id};
	this.command_queue.push(command);
}
this.exe_removePaint = function(){
	this.image_base = null;
	this.image_pattern = null;
}



this.selectBase = function(color){
	switch (color){
		//return the necessary image
	}
}
this.selectPattern = function(pattern, color){
	switch(pattern){
		//return the necessary image
	}
}
this.selectStripeColor = function(color){
	switch(color){
		//return the necessary image
	}
}
this.selectDotColor = function(color){
	switch(color){
		//return the necessary image
	}
}
this.selectStarColor = function(color){
	switch(color){
		//return the necessary image
	}
}

